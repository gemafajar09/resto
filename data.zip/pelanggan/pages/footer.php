                
        <div class="pm-footer-copyright">
        	
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 col-md-5 col-sm-12 pm-footer-copyright-col">
                        <p>©2019 Waroeng Raja Sambal. Produced by <a href="">Skripsi</a></p>
                    </div>
                    
                </div>
            </div>
            
        </div>
    
    </div><!-- /pm_layout-wrapper -->
    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="js/jquery-2.1.1.min.js"></script>
    <script src="js/jquery.viewport.mini.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="bootstrap3/js/bootstrap.min.js"></script>
    <script src="js/modernizr.custom.js"></script>
    <script src="js/owl-carousel/owl.carousel.js"></script>
    <script src="js/main.js"></script>
    <script src="js/jquery.tooltip.js"></script>
    <script src="js/jquery.hoverPanel.js"></script>
    <script src="js/superfish/superfish.js"></script>
    <script src="js/superfish/hoverIntent.js"></script>
    <script src="js/tinynav.js"></script>
    <script src="js/stellar/jquery.stellar.js"></script>
    <script src="js/countdown/countdown.js"></script>
    <script src="js/theme-color-selector/theme-color-selector.js"></script>
	<script src="js/wow/wow.min.js"></script>
    <script src="js/pulse/jquery.PMSlider.js"></script>
    <script src="js/sweetalert.js"></script>
        
    <p id="back-top" class="visible-lg visible-md visible-sm"> </p>
